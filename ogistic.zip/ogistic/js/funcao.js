function formu(){
    f = (document.form.email)
    alert("CADASTRO REALIZADO COM SUCESSO!")}